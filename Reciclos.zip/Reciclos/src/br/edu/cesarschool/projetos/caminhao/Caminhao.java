package br.edu.cesarschool.projetos.caminhao;

public class Caminhao {
	private int placa;
	private long telefone;
	private Empresa empresa;
	private Rota rota;
	
	public Caminhao(int placa, long telefone, Empresa empresa, Rota rota) {
		this.placa = placa;
		this.telefone = telefone;
		this.empresa = empresa;
		this.rota = rota;
	}

	public int getPlaca() {
		return placa;
	}

	public void setPlaca(int placa) {
		this.placa = placa;
	}

	public long getTelefone() {
		return telefone;
	}

	public void setTelefone(long telefone) {
		this.telefone = telefone;
	}

	public Empresa getEmpresa() {
		return empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}

	public Rota getRota() {
		return rota;
	}

	public void setRota(Rota rota) {
		this.rota = rota;
	}
	
	
	
	

}
