package br.edu.cesarschool.projetos.caminhao;

public class Rota {
	private int data;
	private String endereco;
	private long cep;
	
	public Rota(int data, String endereco, long cep) {
		this.data = data;
		this.endereco = endereco;
		this.cep = cep;
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public long getCep() {
		return cep;
	}

	public void setCep(long cep) {
		this.cep = cep;
	}
	
	
	
	

}
