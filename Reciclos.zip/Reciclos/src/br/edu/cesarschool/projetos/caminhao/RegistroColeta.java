package br.edu.cesarschool.projetos.caminhao;

public class RegistroColeta extends PontoColeta{
	private long numRegistro;
	private Caminhao[] caminhoes;

	public RegistroColeta(long id, String endereco, Lixo[] lixos, long numRegistro, Caminhao[] caminhoes) {
		super(id, endereco, lixos);
		this.numRegistro = numRegistro;
		this.caminhoes = caminhoes;
	}

	public long getNumRegistro() {
		return numRegistro;
	}

	public void setNumRegistro(long numRegistro) {
		this.numRegistro = numRegistro;
	}

	public Caminhao[] getCaminhoes() {
		return caminhoes;
	}

	public void setCaminhoes(Caminhao[] caminhoes) {
		this.caminhoes = caminhoes;
	}
	
	
	
	

}
